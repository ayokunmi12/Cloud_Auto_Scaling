function Q=initq()
%% This function initialize the q-values in the look up table
% Authors: Pooyan Jamshidi (pooyan.jamshidi@gmail.com)

global NS NA
globalfql % global parameters initialized

Q=zeros(NS,NA);

end